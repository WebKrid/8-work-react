import { errorTodos } from "../actions/actions"
import { ERROR_TODUS } from "../actions/actionsTypes"

const initialStore = {
   todos: []
   loading: false, 
   error: null
}

export const todosReducer = (state = initialState, action) => {  
   switch (action.type) {
    case GET_TOODS:
        return {
         ...state,
         loading: true, /
         toods: action.payload 
         loading: false
        }
     case ERROR_TODUS:
      return {
         ...state,
         error: action.payload
         loading: false;
      }
      default: 
      return state
   }
}

export const loadTodos = () => { 
   return async dispatch  => {
      dispatch(loadigTodos())
      try {
    const response = await fetch('https://jsonplaceholder.typicode.com/todos');
    const data = await response.json(); 
    dispatch( getTodos(data))
   } catch (e) {
   dispatch(errorTodos(e))
   }
}  