export const todosSelector = state => state.todos;
export const loadingSelector = state => state.loading;
export const errorSelector = state => state.console.error;