import { ERROR_TODUS, GET_TODOS, LOADING_TODOS } from "./actionsTypes";

export const getTodos = (data) => ({
   type: GET_TODOS,
   payload: data
})

export const loadigTodos = () ({
   type: LOADING_TODOS
})

export const errorTodos = (error) => ({
   type: ERROR_TODUS,
   payload: error
})