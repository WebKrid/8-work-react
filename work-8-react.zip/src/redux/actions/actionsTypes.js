


export const GET_TODOS = 'GET_TOODS';
export const LOADING_TODOS = 'LOADING_TODOS';
export const ERROR_TODUS = 'LOADING_TODUS';