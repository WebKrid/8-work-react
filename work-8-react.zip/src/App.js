import { response } from "express";
import { useEffect, useState } from "react";
import { loadTodos } from "./redux/reducer/todosReducer";


function App() {
 const todos = useSelector(todosSelector);  
    const loading = useSelector(loadingSelector);  
    const error = useSelector(errorSelector)
  const dispatch = useDispatch();

  useEffect( () => {
    dispatch(loadTodos)()
  }, [])


  if(loading){
    return (
      <div>
        <h3>Идет загрузка...</h3>
      </div>
    )
  };


  if (error) {
    return (
      <div>
        Произошла ошибка...
      </div>
    )
  }

  return (
    <div>
     {todos.map((todo) => (
      <div key={todo.id}>{todo.title}</div>
     ))}
    </div>
  );
}

export default App;